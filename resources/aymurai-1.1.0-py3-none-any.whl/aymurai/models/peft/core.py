import re
from copy import deepcopy
from functools import partial
from itertools import groupby

import torch
import numpy as np
from more_itertools import unzip

from aymurai.logging import get_logger
from aymurai.meta.types import DataItem, DataBlock
from aymurai.meta.pipeline_interfaces import TrainModule
from aymurai.models.peft.loader import (
    load_tokenizer,
    load_ner_adapter,
    load_ner_labels_mapping,
)

logger = get_logger(__name__)


class NERPeftModel(TrainModule):
    def __init__(
        self,
        name: str,
        device: str = "cpu",
    ):
        self.name = name
        self.model = load_ner_adapter(name)
        self.labels = load_ner_labels_mapping(name)

        self.peft_config = self.model.peft_config
        self.base_model = self.peft_config["default"].base_model_name_or_path

        self.tokenizer = load_tokenizer(self.base_model)

        self.aggregator = "first"
        self.label2code = {k: i for i, k in enumerate(self.labels)}
        self.code2label = {v: k for k, v in self.label2code.items()}

        self.ignore_label = ["O"]

    @property
    def device(self):
        return self.model.device

    @device.setter
    def device(self, value):
        self.model.to(torch.device(value))

    @classmethod
    def load(cls, path: str, **kwargs):
        return cls(name=path, **kwargs)

    def fit(self, train: DataBlock, val: DataBlock):
        raise NotImplementedError("Not implemented")

        # def predict(self, data: DataBlock) -> DataBlock:
        #     logger.info("flair batch prediction")
        #     # data = [self.predict_single(item) for item in data]

        #     # return data
        #     data = deepcopy(data)

        #     docs = [item["data"]["doc.text"] for item in data]

        #     return data

        # def set_ents(self, item: DataItem, ents: list[dict]) -> DataItem:
        #     item = deepcopy(item)
        #     if "predictions" not in item:
        #         item["predictions"] = {}

        #     # overwrite predictions entities
        #     item["predictions"]["entities"] = list(ents)
        #     return item

        # def format_entity(self, sentence: Sentence) -> dict:
        #     """
        #     format single flair entity to aymurai format

        #     Args:
        #         sentence (Sentence): document sentence

        #     Returns:
        #         dict: aymuray entity format
        #     """

        #     # pattern to match
        #     pattern = r"Span\[(\d+):(\d+)\]"

        #     label = sentence.get_label()
        #     text = label.data_point.text
        #     full_tokens = sentence.sentence.tokens

        #     label_value = label.value
        #     score = label.score

        #     start, end = re.findall(pattern, label.labeled_identifier)[0]
        #     start, end = int(start), int(end)

        #     start_char = label.data_point.start_position
        #     end_char = label.data_point.end_position

        #     # context surround
        #     last_token_idx = len(full_tokens)
        #     soffset = max(0, start - self.offset)
        #     eoffset = min(last_token_idx, end + self.offset)

        #     context_pre = " ".join([t.text for t in full_tokens[soffset:start]])
        #     context_post = " ".join([t.text for t in full_tokens[end:eoffset]])

        #     return {
        #         "start": int(start),
        #         "end": int(end),
        #         "label": label_value,
        #         "text": text,
        #         "start_char": start_char,
        #         "end_char": end_char,
        #         "context_pre": context_pre,
        #         "context_post": context_post,
        #         "attrs": {
        #             "aymurai_score": score,
        #             "aymurai_method": "ner/flair",
        #             "aymurai_label": label_value,
        #             # "aymurai_label_subclass": [],
        #         },
        #     }

        # def format_entities(self, sentences: list[flair.data.Span]) -> list[dict]:
        # """
        # format list of entities to aymurai format

        # Args:
        #     sentences (list[flair.data.Span]): list of flair spans

        # Returns:
        #     list[dict]: aymurai format
        # """

        # # if not sentences return empty list
        # if not sentences:
        #     return []

        # return [self.format_entity(sentence) for sentence in sentences]

    def postprocessor(
        self,
        token_ids: list[int],
        scores: list[float],
    ) -> tuple[str, float]:
        text = self.tokenizer.convert_tokens_to_string(token_ids)
        text = re.sub("\s+", "", text)

        # use the label of the top class of subwords
        if self.aggregator == "max":
            score = np.max(scores)
            label_id = np.argmax(scores)
        elif self.aggregator == "first":
            score = np.max(scores[0])
            label_id = np.argmax(scores[0])
        else:
            raise NotImplementedError(
                f"aggregation: `{self.aggregator}` not implemented."
            )
        # if label_id not in code2label:
        #     logger.warn(f"out of range class: `{text}` (label_id {label_id})")
        label = self.code2label.get(label_id, "O")

        return text, label, score

    def predict_single(self, item: DataItem) -> DataItem:
        item = deepcopy(item)

        text = item["data"]["doc.text"]

        inputs = self.tokenizer(
            text.split(),
            return_tensors="pt",
            is_split_into_words=True,
            truncation=True,
        )
        word_ids = inputs.word_ids()
        tokens = inputs.tokens()

        with torch.no_grad():
            logits = self.model(**inputs).logits.numpy()

        maxes = np.max(logits, axis=-1, keepdims=True)
        shifted_exp = np.exp(logits - maxes)
        scores = shifted_exp / shifted_exp.sum(axis=-1, keepdims=True)

        preds = groupby(zip(word_ids, tokens, scores[0]), key=lambda x: x[0])
        preds = filter(
            lambda x: x[0] is not None, preds
        )  # drop non words tokens i.e [CLS]
        _, preds = unzip(preds)  # drop group key (word id)
        preds = map(lambda x: list(zip(*x)), preds)  # transpose list

        # x = (word_id, token_ids, scores)
        preds = map(lambda x: self.postprocessor(x[1], x[2]), preds)
        preds = list(preds)
        # preds = next(preds)

        _align_predictions = partial(self._align_predictions, text)
        # ents = map(_align_predictions, preds)
        ents = self._align_predictions(text, preds)
        ents = groupby(ents, key=lambda x: x[3])
        ents = map(lambda x: self._format_entity(*x, text=text), ents)

        if "predictions" not in item:
            item["predictions"] = {}

        # overwrite predictions entities
        item["predictions"]["entities"] = list(ents)

        return item

    def _align_predictions(self, text: str, pred: list):
        text = deepcopy(text)

        for pp in pred:
            word, label, score = pp

            label = re.sub(r"[BI]-", "", label)

            match = re.search(word, text)
            start = match.start()
            end = match.end()
            length = end - start

            text = text[:start] + " " * length + text[end:]

            if label in self.ignore_label:
                continue

            yield start, end, word, label, score

    def _format_entity(self, label, aligned_preds: list, text: str):
        # print(">>", label, list(aligned_preds))
        start, end, *_, score = unzip(aligned_preds)

        start_char = min(start)
        end_char = max(end)
        score = max(score)
        return {
            "start": 0,
            "end": 0,
            "label": label,
            "text": text,
            "start_char": start_char,
            "end_char": end_char,
            "context_pre": "",
            "context_post": "",
            "attrs": {
                "aymurai_score": float(score),
                "aymurai_method": self.name,
                "aymurai_label": label,
                # "aymurai_label_subclass": [],
            },
        }
        print(">>>", start, end, score)

    # def predict_single(self, item: DataItem) -> DataItem:
    #     item = deepcopy(item)

    #     doc = item["data"]["doc.text"]

    #     sentences = doc.splitlines() if self.split_doc else [doc]

    #     # number of tokens and characters per line
    #     n_tokens = [len(line.split()) for line in sentences]
    #     n_chars = [len(line) for line in sentences]

    #     sentences = [Sentence(sent, use_tokenizer=self.tokenizer) for sent in sentences]

    #     self.model.predict(sentences)
    #     sentences = [sentence.get_spans("ner") for sentence in sentences]

    #     ents = map(self.format_entities, sentences)
    #     ents = list(ents)

    #     # fix entities spans indices (start/end) to the original document
    #     accumulated_tokens = np.cumsum(n_tokens)
    #     for i, _ in enumerate(accumulated_tokens):
    #         if i == 0 or not ents[i]:
    #             continue

    #         for ent in ents[i]:
    #             ent["start"] += accumulated_tokens[i - 1] + i
    #             ent["end"] += accumulated_tokens[i - 1] + i

    #     accumulated_chars = np.cumsum(n_chars)
    #     for i, _ in enumerate(accumulated_chars):
    #         if i == 0 or not ents[i]:
    #             continue

    #         for ent in ents[i]:
    #             ent["start_char"] += accumulated_chars[i - 1] + i
    #             ent["end_char"] += accumulated_chars[i - 1] + i

    #     # filter empty entities
    #     ents = filter(bool, ents)
    #     ents = collapse(ents, base_type=dict)

    #     if "predictions" not in item:
    #         item["predictions"] = {}

    #     # overwrite predictions entities
    #     item["predictions"]["entities"] = list(ents)

    #     return item
