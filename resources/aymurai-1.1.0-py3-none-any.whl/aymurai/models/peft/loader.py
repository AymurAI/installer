from functools import cache

import srsly
from transformers import AutoTokenizer
from huggingface_hub import hf_hub_download
from peft import AutoPeftModelForTokenClassification

from aymurai.logging import get_logger

logger = get_logger(__name__)


@cache
def load_tokenizer(model_name: str):
    logger.info(f"Loading model tokenizer (`{model_name}`)")
    return AutoTokenizer.from_pretrained(model_name)


@cache
def load_ner_labels_mapping(name: str) -> dict[str, int]:
    LABEL2CODE_PATH = hf_hub_download(repo_id=name, filename="label2code.json")
    with open(LABEL2CODE_PATH) as file:
        label2code = srsly.json_loads(file.read())
    return tuple(label2code.keys())


@cache
def load_ner_adapter(name):
    labels = load_ner_labels_mapping(name)
    label2code = {label: i for i, label in enumerate(labels)}

    return AutoPeftModelForTokenClassification.from_pretrained(
        name,
        num_labels=len(label2code.keys()),
        label2id=label2code,
    )
