from .paths import resolve_package_path
