from .pipeline import AymurAIPipeline  # noqa
