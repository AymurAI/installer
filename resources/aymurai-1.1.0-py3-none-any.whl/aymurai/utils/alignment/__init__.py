from .ia2 import norm_ia2_label
from .core import align_docs, align_text
